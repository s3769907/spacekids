<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  
<table>
<?php 
echo "<h2> Method = ";
echo $_SERVER["REQUEST_METHOD"];
echo "</h2>";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($_POST as $key => $value) {
        echo "<tr>";
        echo "<td>";
        echo $key;
        echo "</td>";
        echo "<td>";
        echo $value;
        echo "</td>";
        echo "</tr>";
    }
} else 
if ($_SERVER["REQUEST_METHOD"] == "GET") { 
    foreach ($_GET as $key => $value) {
        echo "<tr>";
        echo "<td>";
        echo $key;
        echo "</td>";
        echo "<td>";
        echo $value;
        echo "</td>";
        echo "</tr>";
    }
}


?>
</table>
</body>
</html>